/**
 * List of Controllers module components
 * Please add your own controller here.
 */
define(
        [
        'public/js/controllers/HelloController1',
        'public/js/controllers/HelloController2',
        'public/js/controllers/HelloController3',
        'public/js/controllers/updaterCtrl',
        'public/js/controllers/welcomeCtrl'
        ],
        function () {}
);