// Set up some core settings
// App version
window.settings = window.settings || {};
window.settings.appVersion = '0.8';